package org.example.entities;

import jakarta.persistence.*;
import org.example.static_data.Status;

import java.time.LocalDateTime;

@Entity
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long appointmentId;
    private String patientName;
    private String note;

    @Enumerated(EnumType.STRING)
    private Status status;
    private LocalDateTime beginAt;
    private LocalDateTime endAt;
    @ManyToOne
    @JoinColumn(name = "doctor_ID")
    private Doctor doctor;



}
