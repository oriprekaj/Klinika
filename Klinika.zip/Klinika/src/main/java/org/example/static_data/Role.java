package org.example.static_data;

public enum Role {
    ADMIN,
    EMPLOYEE
}
