package org.example.static_data;

public enum Status {
    CREATED,
    CANCELLED,
    FINISHED
}
